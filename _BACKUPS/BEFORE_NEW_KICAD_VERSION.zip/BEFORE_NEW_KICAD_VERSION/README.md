# Seminarkurs2021

  Entwicklung eines turingvollständigen, primitiven Microcontroller in der Software Digital
  
  
